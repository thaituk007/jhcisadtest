<?php
use rmrevin\fontawesome\FAS;
use rmrevin\fontawesome\NpmProAssetBundle;
/* @var $this yii\web\View */
$this->title = 'JHCIS Audit DATA Version 2021.04.0001';
echo 'PHP version: ' . phpversion();
?>
<div class="site-index">
    <div class="jumbotron">
        <h2></h2>
        <p class="lead">Open API :) สำหรับนักพัฒนา https://covid19.ddc.moph.go.th/th/api</p>
        <p><a class="btn btn-success" href="https://covid19.ddc.moph.go.th/th/api">Open API :) สำหรับนักพัฒนา</a></p>
        <p class="lead">สำหรับตรวจสอบข้อมูล 43 แฟ้ม บน JHCIS</p>
        <p><a class="btn btn-success" href="http://127.0.0.1/covidapiyii/frontend/web/">JHCIS Audit DATA</a></p>
    </div>
<html lang="en">
<head>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
</head>
<body>
    <div class="covid19"></div>
    <script>
    $.getJSON('https://covid19.th-stat.com/api/open/today', function(data) {

        var text = `ยื่นยัน : ${data.Confirmed} ราย   ติดเชื้อสะสมเพิ่มเติม : ${data.NewConfirmed} ราย <br>
                    รักษาอยู่ใน รพ. : ${data.Hospitalized} ราย  รักษาหายเพิ่มเติม : ${data.NewRecovered} ราย  หายแล้ว : ${data.Recovered} ราย <br>
                    เสียชีวิต : ${data.Deaths} ราย    เสียชีวิตเพิ่มเติม : ${data.NewDeaths} ราย <br>
                    เข้ารับการรักษาใหม่ใน รพ. : ${data.NewHospitalized} ราย <br>
                    วันที่ปรับปรุงข้อมูล : ${data.UpdateDate} แหล่งที่มาของข้อมูล : ${data.Source} <br>`
        $(".covid19").html(text);
    });
    </script>
</body>
</html>
