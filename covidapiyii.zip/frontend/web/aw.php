rmrevin\yii\fontawesome\AssetBundle::register($this);
