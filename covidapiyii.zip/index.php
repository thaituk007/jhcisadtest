<script>
   window.location = './frontend/web' 
</script>
